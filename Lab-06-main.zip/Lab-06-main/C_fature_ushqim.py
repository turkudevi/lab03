cmimi_njesi = float(input("Cmimi njesi (Lek): "))

sasia = int(input("Sasia (cope): "))
if sasia < 0:
    print("Gabim: Sasia nuk mund te jete negative.")
    exit()

karte_studenti = input("Ke karte studenti? (po/jo): ").lower().strip()

nentotal = cmimi_njesi * sasia
zbritje = 0
if karte_studenti == "po":
    zbritje = 0.10 * nentotal
totali = nentotal - zbritje

print("-" * 30)
print(f"Nën-total: {round(nentotal, 2)} Lek")
print(f"Zbritja: {round(zbritje, 2)} Lek")
print(f"Totali: {round(totali, 2)} Lek")
