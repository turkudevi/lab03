mosha = 17
cmimi = 149.99
emri = "Arta"
ka_karte = True

print(emri, type(emri))
print(mosha, type(mosha))
print(cmimi, type(cmimi))
print(ka_karte, type(ka_karte))

input_mosha = input("Shkruaj moshen: ")
print("Para :", type(input_mosha))
input_mosha = int(input_mosha)
print("Pas :", type(input_mosha))

input_cmimi = input("Shkruaj cmimin: ")
print("Para :", type(input_cmimi))
input_cmimi = float(input_cmimi)
print("Pas :", type(input_cmimi))
