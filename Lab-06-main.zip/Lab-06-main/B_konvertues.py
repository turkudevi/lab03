km = float(input("Kilometrat: "))
m = km * 1000

ditet = int(input("Ditet e qendrimit: "))

print(f"Do te ecesh {m} metra ne total dhe do te rrish {ditet} dite.")
print(f"Tipet: {type(m)} dhe {type(ditet)}")
