def pershendetje():
    print("Mire se erdhe ne Lab 12!")

def celsius_ne_fahrenheit(c):
    return c * 9 / 5 + 32

pershendetje()
print(celsius_ne_fahrenheit(25))

print(celsius_ne_fahrenheit(0)) 
print(celsius_ne_fahrenheit(37))  
