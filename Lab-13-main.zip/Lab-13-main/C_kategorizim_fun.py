def notat_ne_fjale(n: float) -> str:
    if n < 0 or n > 10:
        return "Jashte intervalit"
    elif n < 5:
        return "Dobet"
    elif n < 7:
        return "Mjaftueshem"
    elif n < 9:
        return "Mire"
    else:
        return "Shkelqyeshem"
    
def eshte_abonuar(kodi: str) -> bool:
    return kodi.strip().upper() == "TIK12"

def main():
    try:
        nota = float(input("Nota: "))
        kodi = input("Kodi: ")

        print(notat_ne_fjale(nota))

        if eshte_abonuar(kodi):
            print("Abonimi: Po")
        else:
            print("Abonimi: Jo")

    except ValueError:
        print("Gabim ne hyrje. Ju lutem jepni nje numer per noten.")
main()
