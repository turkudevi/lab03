def format_lek(vlera: float) -> str:
    return f"{vlera:,.2f} Lek"

def main():
    try:
        shuma = float(input("Shuma: "))
        print(format_lek(shuma))
    except ValueError:
        print("Ju lutem jepni një vlere numerike.")

main()
